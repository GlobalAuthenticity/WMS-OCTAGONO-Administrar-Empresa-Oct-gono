<?php
/**
 * Registro del menú de administración y renderizado de la página.
 *
 * @package GestionEmpresas
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GE_Admin_Page {

	const PAGE_SLUG = 'gestion-empresas';

	/**
	 * Registra la página en el menú de administración de WordPress.
	 */
	public function register_menu() {
		add_menu_page(
			__( 'Empresas', 'gestion-empresas' ),
			__( 'Empresas', 'gestion-empresas' ),
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render_page' ),
			'dashicons-building',
			26
		);
	}

	/**
	 * Encola CSS/JS únicamente en la pantalla del plugin.
	 *
	 * @param string $hook Hook de la pantalla actual de admin.
	 */
	public function enqueue_assets( $hook ) {
		if ( 'toplevel_page_' . self::PAGE_SLUG !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'ge-admin-css',
			GE_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			GE_PLUGIN_VERSION
		);

		// SweetAlert2 (CDN) para las confirmaciones y mensajes de estado.
		wp_enqueue_script(
			'sweetalert2',
			'https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.10.1/sweetalert2.all.min.js',
			array(),
			'11.10.1',
			true
		);

		wp_enqueue_script(
			'ge-admin-js',
			GE_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery', 'sweetalert2' ),
			GE_PLUGIN_VERSION,
			true
		);

		wp_localize_script(
			'ge-admin-js',
			'GE_Admin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( GE_Ajax_Controller::NONCE_ACTION ),
				'i18n'    => array(
					'confirmTitle'      => __( '¿Eliminar esta empresa?', 'gestion-empresas' ),
					'confirmTextPrefix' => __( 'Esta acción es irreversible. Se eliminará de forma permanente la empresa', 'gestion-empresas' ),
					'confirmTextSuffix' => __( 'junto con todas sus áreas, usuarios y datos relacionados (progreso de cursos, membresías, exámenes, certificados, pedidos, etc.). Esta operación no se puede deshacer.', 'gestion-empresas' ),
					'confirmButton'     => __( 'Sí, eliminar empresa', 'gestion-empresas' ),
					'cancelButton'      => __( 'Cancelar', 'gestion-empresas' ),
					'progressTitle'     => __( 'Eliminando empresa…', 'gestion-empresas' ),
					'progressText'      => __( 'Por favor espera, este proceso puede tardar unos segundos. No cierres esta ventana.', 'gestion-empresas' ),
					'successTitle'      => __( '¡Listo!', 'gestion-empresas' ),
					'errorTitle'        => __( 'No se pudo completar', 'gestion-empresas' ),
					'genericError'      => __( 'Ocurrió un error inesperado. Intenta nuevamente.', 'gestion-empresas' ),
					'searching'         => __( 'Buscando…', 'gestion-empresas' ),
				),
			)
		);
	}

	/**
	 * Renderiza el contenedor de la página. La tabla se pinta por PHP en
	 * la carga inicial y se refresca vía AJAX en búsquedas/orden/paginación.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos para acceder a esta página.', 'gestion-empresas' ) );
		}

		$list_table = new GE_List_Table();
		$list_table->prepare_items();
		?>
		<div class="wrap ge-wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Empresas registradas', 'gestion-empresas' ); ?></h1>
			<hr class="wp-header-end">

			<p class="description ge-subtitle">
				<?php esc_html_e( 'Administra las empresas (cuentas group_admin) del sistema, sus áreas asociadas y elimina de forma segura la información relacionada.', 'gestion-empresas' ); ?>
			</p>

			<form id="ge-search-form" method="get">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>" />
				<p class="search-box">
					<label class="screen-reader-text" for="ge-search-input"><?php esc_html_e( 'Buscar empresas', 'gestion-empresas' ); ?></label>
					<input type="search" id="ge-search-input" name="s" value="<?php echo esc_attr( isset( $_REQUEST['s'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['s'] ) ) : '' ); ?>" placeholder="<?php esc_attr_e( 'Buscar por nombre o correo…', 'gestion-empresas' ); ?>" />
					<span id="ge-search-spinner" class="spinner"></span>
				</p>
			</form>

			<div id="ge-table-container">
				<?php $list_table->display(); ?>
			</div>
		</div>

		<!-- Modal de progreso durante la eliminación -->
		<div id="ge-progress-overlay" class="ge-progress-overlay" hidden>
			<div class="ge-progress-box">
				<p class="ge-progress-title"></p>
				<div class="ge-progress-bar">
					<div class="ge-progress-bar-fill"></div>
				</div>
				<p class="ge-progress-text"></p>
			</div>
		</div>
		<?php
	}
}
