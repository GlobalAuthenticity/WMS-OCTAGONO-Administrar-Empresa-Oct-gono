<?php
/**
 * Clase principal del plugin: registra hooks de WordPress.
 *
 * @package GestionEmpresas
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GE_Plugin {

	/**
	 * Controlador de acciones AJAX.
	 *
	 * @var GE_Ajax_Controller
	 */
	protected $ajax_controller;

	/**
	 * Página de administración.
	 *
	 * @var GE_Admin_Page
	 */
	protected $admin_page;

	/**
	 * Inicializa el plugin registrando todos los hooks necesarios.
	 */
	public function init() {
		$this->admin_page      = new GE_Admin_Page();
		$this->ajax_controller = new GE_Ajax_Controller();

		add_action( 'admin_menu', array( $this->admin_page, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this->admin_page, 'enqueue_assets' ) );

		$this->ajax_controller->register_hooks();

		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
	}

	/**
	 * Carga el dominio de traducción del plugin.
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'gestion-empresas', false, dirname( GE_PLUGIN_BASENAME ) . '/languages' );
	}
}
