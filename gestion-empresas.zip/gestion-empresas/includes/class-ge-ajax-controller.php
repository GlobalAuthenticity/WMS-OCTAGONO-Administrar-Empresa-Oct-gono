<?php
/**
 * Controlador AJAX del plugin.
 *
 * Centraliza todas las peticiones AJAX relacionadas con el listado y la
 * eliminación de empresas. No contiene lógica de negocio: delega en los
 * servicios correspondientes.
 *
 * @package GestionEmpresas
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GE_Ajax_Controller {

	const NONCE_ACTION = 'ge_ajax_nonce';

	/**
	 * @var GE_Deletion_Service
	 */
	protected $deletion_service;

	public function __construct() {
		$this->deletion_service = new GE_Deletion_Service();
	}

	/**
	 * Registra los hooks de WordPress para las acciones AJAX.
	 */
	public function register_hooks() {
		add_action( 'wp_ajax_ge_search_companies', array( $this, 'handle_search' ) );
		add_action( 'wp_ajax_ge_delete_company', array( $this, 'handle_delete' ) );
	}

	/**
	 * Verifica capacidad y nonce; corta la ejecución con un error JSON si falla.
	 */
	protected function guard() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No tienes permisos suficientes para realizar esta acción.', 'gestion-empresas' ) ),
				403
			);
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
	}

	/**
	 * AJAX: devuelve el HTML de la tabla (filas) según búsqueda/orden/paginación.
	 */
	public function handle_search() {
		$this->guard();

		$list_table = new GE_List_Table();
		$list_table->prepare_items();

		ob_start();
		$list_table->display();
		$table_html = ob_get_clean();

		wp_send_json_success(
			array(
				'table_html' => $table_html,
			)
		);
	}

	/**
	 * AJAX: elimina una empresa y toda su información dependiente.
	 */
	public function handle_delete() {
		$this->guard();

		$company_id = isset( $_POST['company_id'] ) ? absint( $_POST['company_id'] ) : 0;

		if ( ! $company_id ) {
			wp_send_json_error(
				array( 'message' => __( 'ID de empresa no válido.', 'gestion-empresas' ) ),
				400
			);
		}

		$result = $this->deletion_service->delete_company( $company_id );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}

		wp_send_json_success( array( 'message' => $result['message'] ) );
	}
}
