<?php
/**
 * Servicio encargado de la eliminación completa y transaccional de una
 * empresa (usuario group_admin) y de toda la información dependiente:
 *
 *   Paso 1: áreas de la empresa      -> wp_areas (grupo_id)
 *   Paso 2: usuarios de esas áreas   -> wp_user_members (area_id)
 *   Paso 3: borrado en cascada de cada usuario en todas las tablas
 *           dependientes del sistema (usuarios, metadatos, membresías,
 *           progreso de cursos, exámenes, certificados, WooCommerce, etc.)
 *   Paso 4: borrado de wp_user_members, wp_areas, el usuario group_admin
 *           y sus metadatos.
 *
 * Toda la operación se ejecuta dentro de una única transacción SQL
 * (START TRANSACTION / COMMIT / ROLLBACK) para garantizar que, ante
 * cualquier fallo, no quede ningún dato eliminado parcialmente.
 *
 * @package GestionEmpresas
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Excepción interna usada para abortar la transacción de forma controlada.
 */
class GE_Deletion_Exception extends Exception {}

class GE_Deletion_Service {

	/**
	 * @var wpdb
	 */
	protected $db;

	/**
	 * @var GE_Company_Service
	 */
	protected $company_service;

	public function __construct() {
		global $wpdb;
		$this->db              = $wpdb;
		$this->company_service = new GE_Company_Service();
	}

	/**
	 * Elimina por completo una empresa y todos sus registros relacionados.
	 *
	 * @param int $company_id ID del usuario group_admin.
	 * @return array {
	 *     @type bool   $success
	 *     @type string $message
	 * }
	 */
	public function delete_company( $company_id ) {
		$company_id = absint( $company_id );

		$company = $this->company_service->get_company( $company_id );
		if ( ! $company ) {
			return array(
				'success' => false,
				'message' => __( 'La empresa indicada no existe o no tiene el rol correspondiente.', 'gestion-empresas' ),
			);
		}

		// Evitar transacciones anidadas si el motor no las soporta bien.
		$this->db->query( 'START TRANSACTION' );

		try {
			// -----------------------------------------------------------
			// Paso 1: áreas de la empresa.
			// -----------------------------------------------------------
			$area_ids = $this->get_area_ids( $company_id );

			// -----------------------------------------------------------
			// Paso 2: usuarios (estudiantes/miembros) de esas áreas.
			// -----------------------------------------------------------
			$member_user_ids = $this->get_member_user_ids( $area_ids );

			// -----------------------------------------------------------
			// Paso 3: eliminar en cascada cada usuario relacionado.
			// -----------------------------------------------------------
			foreach ( $member_user_ids as $user_id ) {
				$this->delete_user_completely( $user_id );
			}

			// -----------------------------------------------------------
			// Paso 4: eliminar relaciones, áreas y la empresa misma.
			// -----------------------------------------------------------
			$this->delete_user_members_by_area( $area_ids );
			$this->delete_areas( $company_id );

			/**
			 * Permite a otros plugins/módulos añadir limpieza adicional
			 * dentro de la MISMA transacción antes del COMMIT final.
			 *
			 * @param int   $company_id
			 * @param array $area_ids
			 * @param array $member_user_ids
			 */
			do_action( 'ge_before_company_commit', $company_id, $area_ids, $member_user_ids );

			// Finalmente, el propio usuario "empresa" (group_admin).
			$this->delete_user_completely( $company_id );

			$this->db->query( 'COMMIT' );

			return array(
				'success' => true,
				'message' => __( 'Empresa eliminada correctamente.', 'gestion-empresas' ),
			);

		} catch ( Exception $e ) {
			$this->db->query( 'ROLLBACK' );

			return array(
				'success' => false,
				'message' => __( 'No fue posible eliminar la empresa. No se realizaron cambios en la base de datos.', 'gestion-empresas' ),
				'debug'   => $e->getMessage(),
			);
		}
	}

	/**
	 * Ejecuta una consulta y lanza excepción si falla.
	 *
	 * @param string $sql Consulta preparada.
	 * @throws GE_Deletion_Exception
	 * @return int|bool Resultado de $wpdb->query().
	 */
	protected function run( $sql ) {
		$result = $this->db->query( $sql );

		if ( false === $result ) {
			throw new GE_Deletion_Exception( $this->db->last_error ? $this->db->last_error : 'Error desconocido de base de datos.' );
		}

		return $result;
	}

	/**
	 * Obtiene los IDs de área asociados a una empresa.
	 *
	 * @param int $company_id
	 * @return int[]
	 */
	protected function get_area_ids( $company_id ) {
		$sql = $this->db->prepare(
			"SELECT id FROM {$this->db->prefix}areas WHERE grupo_id = %d",
			$company_id
		);

		$ids = $this->db->get_col( $sql );

		if ( null === $ids && $this->db->last_error ) {
			throw new GE_Deletion_Exception( $this->db->last_error );
		}

		return array_map( 'absint', (array) $ids );
	}

	/**
	 * Obtiene los IDs de usuario asociados a un conjunto de áreas.
	 *
	 * @param int[] $area_ids
	 * @return int[]
	 */
	protected function get_member_user_ids( array $area_ids ) {
		if ( empty( $area_ids ) ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $area_ids ), '%d' ) );

		$sql = $this->db->prepare(
			"SELECT DISTINCT user_id FROM {$this->db->prefix}user_members WHERE area_id IN ({$placeholders})",
			$area_ids
		);

		$ids = $this->db->get_col( $sql );

		if ( null === $ids && $this->db->last_error ) {
			throw new GE_Deletion_Exception( $this->db->last_error );
		}

		return array_map( 'absint', (array) $ids );
	}

	/**
	 * Elimina wp_user_members para un conjunto de áreas.
	 *
	 * @param int[] $area_ids
	 */
	protected function delete_user_members_by_area( array $area_ids ) {
		if ( empty( $area_ids ) ) {
			return;
		}

		$placeholders = implode( ',', array_fill( 0, count( $area_ids ), '%d' ) );

		$sql = $this->db->prepare(
			"DELETE FROM {$this->db->prefix}user_members WHERE area_id IN ({$placeholders})",
			$area_ids
		);

		$this->run( $sql );
	}

	/**
	 * Elimina las áreas de una empresa.
	 *
	 * @param int $company_id
	 */
	protected function delete_areas( $company_id ) {
		$sql = $this->db->prepare(
			"DELETE FROM {$this->db->prefix}areas WHERE grupo_id = %d",
			$company_id
		);

		$this->run( $sql );
	}

	/**
	 * Elimina TODOS los registros relacionados a un usuario del sistema
	 * (metadatos, membresías, progreso de cursos, exámenes, certificados,
	 * WooCommerce, Ultimate Member, etc.) y finalmente el propio usuario.
	 *
	 * @param int $user_id
	 */
	protected function delete_user_completely( $user_id ) {
		$user_id = absint( $user_id );
		if ( ! $user_id ) {
			return;
		}

		$p = $this->db->prefix;

		// -----------------------------------------------------------
		// Tablas base de WordPress.
		// -----------------------------------------------------------
		$this->delete_by_column( "{$p}usermeta", 'user_id', $user_id );

		// -----------------------------------------------------------
		// Membresías de áreas propias del sistema (wp_user_members).
		// -----------------------------------------------------------
		$this->delete_by_column( "{$p}user_members", 'user_id', $user_id );

		// -----------------------------------------------------------
		// Ultimate Member (metadatos extendidos de perfil).
		// -----------------------------------------------------------
		$this->delete_by_column( "{$p}um_metadata", 'user_id', $user_id );

		// -----------------------------------------------------------
		// LearnDash: progreso, logros, bloqueos, estadísticas.
		// -----------------------------------------------------------
		$activity_ids = $this->get_col_by_column( "{$p}learndash_user_activity", 'activity_id', 'user_id', $user_id );
		if ( ! empty( $activity_ids ) ) {
			$this->delete_by_in( "{$p}learndash_user_activity_meta", 'activity_id', $activity_ids );
		}
		$this->delete_by_column( "{$p}learndash_user_activity", 'user_id', $user_id );
		$this->delete_by_column( "{$p}ld_achievements", 'user_id', $user_id );
		$this->delete_by_column( "{$p}learndash_pro_quiz_lock", 'user_id', $user_id );
		$this->delete_by_column( "{$p}learndash_pro_quiz_statistic_ref", 'user_id', $user_id );
		$this->delete_by_column( "{$p}learndash_pro_quiz_toplist", 'user_id', $user_id );

		// -----------------------------------------------------------
		// WatuPRO / Watu (exámenes, certificados, pagos, desbloqueos).
		// -----------------------------------------------------------
		$this->delete_by_column( "{$p}watupro_payments", 'user_id', $user_id );
		$this->delete_by_column( "{$p}watupro_student_answers", 'user_id', $user_id );
		$this->delete_by_column( "{$p}watupro_taken_exams", 'user_id', $user_id );
		$this->delete_by_column( "{$p}watupro_unlock_logs", 'user_id', $user_id );
		$this->delete_by_column( "{$p}watupro_users_groups", 'user_id', $user_id );
		$this->delete_by_column( "{$p}watupro_user_certificates", 'user_id', $user_id );
		$this->delete_by_column( "{$p}watupro_user_files", 'user_id', $user_id );
		$this->delete_by_column( "{$p}watu_takings", 'user_id', $user_id );

		// -----------------------------------------------------------
		// WooCommerce: tokens de pago, permisos de descarga, lookups.
		// -----------------------------------------------------------
		$token_ids = $this->get_col_by_column( "{$p}woocommerce_payment_tokens", 'token_id', 'user_id', $user_id );
		if ( ! empty( $token_ids ) ) {
			$this->delete_by_in( "{$p}woocommerce_payment_tokenmeta", 'payment_token_id', $token_ids );
		}
		$this->delete_by_column( "{$p}woocommerce_payment_tokens", 'user_id', $user_id );
		$this->delete_by_column( "{$p}woocommerce_downloadable_product_permissions", 'user_id', $user_id );
		$this->delete_by_column( "{$p}wc_download_log", 'user_id', $user_id );
		$this->delete_by_column( "{$p}wc_customer_lookup", 'user_id', $user_id );
		$this->delete_by_column( "{$p}wc_order_product_lookup", 'customer_id', $user_id );
		$this->delete_by_column( "{$p}wc_order_stats", 'customer_id', $user_id );

		// -----------------------------------------------------------
		// Formularios / notas / comentarios propios del usuario.
		// -----------------------------------------------------------
		$this->delete_by_column( "{$p}e_notes_users_relations", 'user_id', $user_id );
		$this->delete_by_column( "{$p}e_submissions", 'user_id', $user_id );
		$this->delete_by_column( "{$p}comments", 'user_id', $user_id );

		/**
		 * Hook de extensión: permite a otros módulos limpiar tablas
		 * adicionales (custom o de terceros) para este usuario, dentro
		 * de la misma transacción.
		 *
		 * @param int    $user_id
		 * @param wpdb   $db
		 */
		do_action( 'ge_delete_user_related_data', $user_id, $this->db );

		// -----------------------------------------------------------
		// Finalmente, el registro del usuario en wp_users.
		// -----------------------------------------------------------
		$this->delete_by_column( "{$p}users", 'ID', $user_id );
	}

	/**
	 * DELETE FROM {table} WHERE {column} = {value}, con verificación de error.
	 *
	 * @param string $table  Nombre completo de tabla (ya con prefijo).
	 * @param string $column Nombre de columna (fijo, no proviene de input de usuario).
	 * @param int    $value  Valor numérico.
	 */
	protected function delete_by_column( $table, $column, $value ) {
		if ( ! $this->table_exists( $table ) ) {
			return;
		}

		$sql = $this->db->prepare(
			"DELETE FROM {$table} WHERE {$column} = %d",
			absint( $value )
		);

		$this->run( $sql );
	}

	/**
	 * DELETE FROM {table} WHERE {column} IN (...ids), con verificación de error.
	 *
	 * @param string $table
	 * @param string $column
	 * @param int[]  $ids
	 */
	protected function delete_by_in( $table, $column, array $ids ) {
		$ids = array_filter( array_map( 'absint', $ids ) );

		if ( empty( $ids ) || ! $this->table_exists( $table ) ) {
			return;
		}

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		$sql = $this->db->prepare(
			"DELETE FROM {$table} WHERE {$column} IN ({$placeholders})",
			$ids
		);

		$this->run( $sql );
	}

	/**
	 * SELECT {select_column} FROM {table} WHERE {where_column} = {value}.
	 *
	 * @param string $table
	 * @param string $select_column
	 * @param string $where_column
	 * @param int    $value
	 * @return int[]
	 */
	protected function get_col_by_column( $table, $select_column, $where_column, $value ) {
		if ( ! $this->table_exists( $table ) ) {
			return array();
		}

		$sql = $this->db->prepare(
			"SELECT {$select_column} FROM {$table} WHERE {$where_column} = %d",
			absint( $value )
		);

		$result = $this->db->get_col( $sql );

		if ( null === $result && $this->db->last_error ) {
			throw new GE_Deletion_Exception( $this->db->last_error );
		}

		return array_map( 'absint', (array) $result );
	}

	/**
	 * Verifica de forma cacheada si una tabla existe en la base de datos
	 * actual. Esto hace que el plugin no falle en instalaciones donde no
	 * estén activos LearnDash, WatuPRO, Ultimate Member, etc.
	 *
	 * @param string $table Nombre completo de tabla (con prefijo).
	 * @return bool
	 */
	protected function table_exists( $table ) {
		static $cache = array();

		if ( isset( $cache[ $table ] ) ) {
			return $cache[ $table ];
		}

		$found = $this->db->get_var(
			$this->db->prepare( 'SHOW TABLES LIKE %s', $table )
		);

		$cache[ $table ] = ( $found === $table );

		return $cache[ $table ];
	}
}
