<?php
/**
 * Servicio de datos para las "empresas" (usuarios con rol group_admin).
 *
 * Toda la lógica de acceso a datos de lectura vive aquí, separada de la
 * capa de presentación (List Table) y de la capa de transporte (AJAX).
 *
 * @package GestionEmpresas
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GE_Company_Service {

	/**
	 * Obtiene un listado paginado y filtrado de empresas.
	 *
	 * @param array $args {
	 *     @type string $search   Término de búsqueda (nombre o correo).
	 *     @type int    $paged    Página actual (1-index).
	 *     @type int    $per_page Elementos por página.
	 *     @type string $orderby  Campo de orden (id|nombre|correo|areas).
	 *     @type string $order    ASC|DESC.
	 * }
	 * @return array {
	 *     @type array $items       Filas ya normalizadas (id, nombre, correo, total_areas).
	 *     @type int   $total_items Total de resultados (sin paginar).
	 * }
	 */
	public function get_companies( array $args = array() ) {
		global $wpdb;

		$defaults = array(
			'search'   => '',
			'paged'    => 1,
			'per_page' => 20,
			'orderby'  => 'id',
			'order'    => 'DESC',
		);
		$args = wp_parse_args( $args, $defaults );

		$user_query_args = array(
			'role'   => GE_COMPANY_ROLE,
			'fields' => array( 'ID', 'display_name', 'user_email', 'user_registered' ),
		);

		if ( ! empty( $args['search'] ) ) {
			$search = '*' . trim( $args['search'] ) . '*';
			$user_query_args['search']         = $search;
			$user_query_args['search_columns'] = array( 'display_name', 'user_email', 'user_login', 'user_nicename' );
		}

		// El orden por "areas" se resuelve después de traer los conteos,
		// ya que WP_User_Query no conoce la tabla wp_areas.
		$order_by_user_query = in_array( $args['orderby'], array( 'id', 'nombre', 'correo' ), true );

		if ( $order_by_user_query ) {
			$map = array(
				'id'     => 'ID',
				'nombre' => 'display_name',
				'correo' => 'user_email',
			);
			$user_query_args['orderby'] = $map[ $args['orderby'] ];
			$user_query_args['order']   = $args['order'];
		}

		// Para poder ordenar por "areas" o paginar correctamente necesitamos
		// primero saber el total de empresas que cumplen el filtro.
		$counting_query               = $user_query_args;
		$counting_query['fields']     = 'ID';
		$counting_query['number']     = -1;
		$all_matching_ids             = ( new WP_User_Query( $counting_query ) )->get_results();
		$total_items                  = count( $all_matching_ids );

		if ( 0 === $total_items ) {
			return array(
				'items'       => array(),
				'total_items' => 0,
			);
		}

		if ( 'areas' === $args['orderby'] ) {
			// Traemos todos los IDs, calculamos su conteo de áreas, ordenamos
			// en PHP y paginamos manualmente.
			$counts = $this->get_area_counts( $all_matching_ids );

			usort(
				$all_matching_ids,
				static function ( $a, $b ) use ( $counts ) {
					$ca = isset( $counts[ $a ] ) ? $counts[ $a ] : 0;
					$cb = isset( $counts[ $b ] ) ? $counts[ $b ] : 0;
					return $ca <=> $cb;
				}
			);

			if ( 'DESC' === strtoupper( $args['order'] ) ) {
				$all_matching_ids = array_reverse( $all_matching_ids );
			}

			$offset      = ( max( 1, (int) $args['paged'] ) - 1 ) * (int) $args['per_page'];
			$page_ids    = array_slice( $all_matching_ids, $offset, (int) $args['per_page'] );
			$users       = empty( $page_ids ) ? array() : get_users(
				array(
					'include' => $page_ids,
					'orderby' => 'include',
					'fields'  => array( 'ID', 'display_name', 'user_email', 'user_registered' ),
				)
			);
		} else {
			$user_query_args['number'] = (int) $args['per_page'];
			$user_query_args['paged']  = max( 1, (int) $args['paged'] );
			$users                     = ( new WP_User_Query( $user_query_args ) )->get_results();
		}

		$ids    = wp_list_pluck( $users, 'ID' );
		$counts = $this->get_area_counts( $ids );

		$items = array();
		foreach ( $users as $user ) {
			$items[] = array(
				'id'          => (int) $user->ID,
				'nombre'      => $user->display_name,
				'correo'      => $user->user_email,
				'total_areas' => isset( $counts[ $user->ID ] ) ? (int) $counts[ $user->ID ] : 0,
			);
		}

		return array(
			'items'       => $items,
			'total_items' => $total_items,
		);
	}

	/**
	 * Devuelve un mapa [user_id => total_areas] para un conjunto de IDs.
	 *
	 * @param array $user_ids IDs de usuarios (empresas).
	 * @return array
	 */
	public function get_area_counts( array $user_ids ) {
		global $wpdb;

		$user_ids = array_map( 'absint', $user_ids );
		$user_ids = array_filter( $user_ids );

		if ( empty( $user_ids ) ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );

		// Nombre de tabla fijo (no proviene de entrada de usuario), IDs preparados.
		$sql = "SELECT grupo_id, COUNT(*) AS total
				FROM {$wpdb->prefix}areas
				WHERE grupo_id IN ({$placeholders})
				GROUP BY grupo_id";

		$prepared = $wpdb->prepare( $sql, $user_ids );
		$rows     = $wpdb->get_results( $prepared );

		$map = array();
		foreach ( $rows as $row ) {
			$map[ (int) $row->grupo_id ] = (int) $row->total;
		}

		return $map;
	}

	/**
	 * Obtiene el total de áreas de una sola empresa.
	 *
	 * @param int $company_id ID de la empresa (usuario group_admin).
	 * @return int
	 */
	public function get_area_count( $company_id ) {
		$map = $this->get_area_counts( array( $company_id ) );
		return isset( $map[ (int) $company_id ] ) ? $map[ (int) $company_id ] : 0;
	}

	/**
	 * Verifica que un usuario exista y tenga el rol de empresa.
	 *
	 * @param int $company_id ID de usuario.
	 * @return WP_User|false
	 */
	public function get_company( $company_id ) {
		$user = get_userdata( (int) $company_id );

		if ( ! $user || ! in_array( GE_COMPANY_ROLE, (array) $user->roles, true ) ) {
			return false;
		}

		return $user;
	}
}
