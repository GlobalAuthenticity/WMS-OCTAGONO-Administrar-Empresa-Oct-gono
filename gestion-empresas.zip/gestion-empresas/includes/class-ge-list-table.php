<?php
/**
 * Tabla de administración para el listado de empresas.
 *
 * @package GestionEmpresas
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class GE_List_Table extends WP_List_Table {

	/**
	 * @var GE_Company_Service
	 */
	protected $service;

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'empresa',
				'plural'   => 'empresas',
				'ajax'     => true,
			)
		);

		$this->service = new GE_Company_Service();
	}

	/**
	 * Columnas visibles de la tabla.
	 *
	 * @return array
	 */
	public function get_columns() {
		return array(
			'empresa' => __( 'Empresa', 'gestion-empresas' ),
			'areas'   => __( 'Áreas', 'gestion-empresas' ),
			'acciones' => __( 'Acciones', 'gestion-empresas' ),
		);
	}

	/**
	 * Columnas ordenables.
	 *
	 * @return array
	 */
	protected function get_sortable_columns() {
		return array(
			'empresa' => array( 'nombre', false ),
			'areas'   => array( 'areas', false ),
		);
	}

	/**
	 * Mensaje cuando no hay resultados.
	 */
	public function no_items() {
		esc_html_e( 'No se encontraron empresas.', 'gestion-empresas' );
	}

	/**
	 * Carga los datos a mostrar según búsqueda, orden y paginación actuales.
	 */
	public function prepare_items() {
		$per_page = 20;
		$paged    = $this->get_pagenum();
		$search   = isset( $_REQUEST['s'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$orderby = isset( $_REQUEST['orderby'] ) ? sanitize_key( $_REQUEST['orderby'] ) : 'id'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$order   = isset( $_REQUEST['order'] ) ? strtoupper( sanitize_key( $_REQUEST['order'] ) ) : 'DESC'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$order   = in_array( $order, array( 'ASC', 'DESC' ), true ) ? $order : 'DESC';

		$result = $this->service->get_companies(
			array(
				'search'   => $search,
				'paged'    => $paged,
				'per_page' => $per_page,
				'orderby'  => $orderby,
				'order'    => $order,
			)
		);

		$this->items = $result['items'];

		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns() );

		$this->set_pagination_args(
			array(
				'total_items' => $result['total_items'],
				'per_page'    => $per_page,
				'total_pages' => (int) ceil( $result['total_items'] / $per_page ),
			)
		);
	}

	/**
	 * Renderiza la columna "Empresa": ID, nombre y correo agrupados.
	 *
	 * @param array $item
	 * @return string
	 */
	protected function column_empresa( $item ) {
		return sprintf(
			'<div class="ge-company-cell">
				<span class="ge-company-name">%1$s</span>
				<span class="ge-company-meta">%2$s #%3$d</span>
				<span class="ge-company-email">%4$s</span>
			</div>',
			esc_html( $item['nombre'] ),
			esc_html__( 'ID', 'gestion-empresas' ),
			absint( $item['id'] ),
			esc_html( $item['correo'] )
		);
	}

	/**
	 * Renderiza la columna "Áreas".
	 *
	 * @param array $item
	 * @return string
	 */
	protected function column_areas( $item ) {
		return sprintf(
			'<span class="ge-badge">%d</span>',
			absint( $item['total_areas'] )
		);
	}

	/**
	 * Renderiza el menú de acciones por fila.
	 *
	 * @param array $item
	 * @return string
	 */
	protected function column_acciones( $item ) {
		$id = absint( $item['id'] );

		ob_start();
		?>
		<div class="ge-actions-dropdown">
			<button type="button" class="button ge-actions-toggle" aria-haspopup="true" aria-expanded="false">
				<?php esc_html_e( 'Acciones', 'gestion-empresas' ); ?> <span class="dashicons dashicons-arrow-down-alt2"></span>
			</button>
			<ul class="ge-actions-menu" hidden>
				<li>
					<a href="#" class="ge-action-delete" data-id="<?php echo esc_attr( $id ); ?>" data-nombre="<?php echo esc_attr( $item['nombre'] ); ?>">
						🗑️ <?php esc_html_e( 'Borrar empresa', 'gestion-empresas' ); ?>
					</a>
				</li>
			</ul>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Columna por defecto (fallback).
	 *
	 * @param array  $item
	 * @param string $column_name
	 * @return string
	 */
	protected function column_default( $item, $column_name ) {
		return isset( $item[ $column_name ] ) ? esc_html( $item[ $column_name ] ) : '';
	}
}
