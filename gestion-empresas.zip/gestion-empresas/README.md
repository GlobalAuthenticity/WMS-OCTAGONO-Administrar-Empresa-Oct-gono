=== Gestión de Empresas ===
Autor: Cristian
Requiere al menos: WordPress 5.8
Probado hasta: 6.x
Requiere PHP: 7.4 o superior
Versión: 1.0.0

Plugin interno para administrar las "empresas" del sistema (usuarios con
rol `group_admin`), sus áreas asociadas (`wp_areas`) y la eliminación en
cascada y transaccional de toda la información relacionada.

== Arquitectura ==

gestion-empresas.php                          -> Bootstrap del plugin.
includes/class-ge-plugin.php                  -> Registra hooks (admin_menu, enqueue, ajax).
includes/class-ge-admin-page.php              -> Menú, render de la página, enqueue de assets, localización JS.
includes/class-ge-list-table.php              -> WP_List_Table: columnas Empresa / Áreas / Acciones.
includes/class-ge-ajax-controller.php         -> Endpoints AJAX: búsqueda/listado y eliminación.
includes/services/class-ge-company-service.php    -> Consultas de lectura (listado, búsqueda, conteo de áreas).
includes/services/class-ge-deletion-service.php   -> Eliminación en cascada dentro de una transacción SQL.
assets/css/admin.css                          -> Estilos del panel.
assets/js/admin.js                            -> Búsqueda AJAX, menú de acciones, SweetAlert2 y barra de progreso.

== Seguridad ==

* Todas las consultas usan `$wpdb->prepare()`.
* Todas las peticiones AJAX verifican `current_user_can( 'manage_options' )`
  y un nonce (`check_ajax_referer`).
* El listado y las acciones solo son visibles/ejecutables por administradores.

== Lógica de eliminación en cascada ==

1. Se obtienen los `id` de `wp_areas` donde `grupo_id` = ID de la empresa.
2. Se obtienen los `user_id` de `wp_user_members` donde `area_id` esté en el
   conjunto anterior.
3. Para cada usuario obtenido se eliminan sus registros en (si la tabla
   existe en la instalación): wp_usermeta, wp_user_members, wp_um_metadata
   (Ultimate Member), wp_learndash_user_activity (+ meta), wp_ld_achievements,
   wp_learndash_pro_quiz_lock/statistic_ref/toplist, wp_watupro_payments,
   wp_watupro_student_answers, wp_watupro_taken_exams, wp_watupro_unlock_logs,
   wp_watupro_users_groups, wp_watupro_user_certificates, wp_watupro_user_files,
   wp_watu_takings, wp_woocommerce_payment_tokens (+ tokenmeta),
   wp_woocommerce_downloadable_product_permissions, wp_wc_download_log,
   wp_wc_customer_lookup, wp_wc_order_product_lookup, wp_wc_order_stats,
   wp_e_notes_users_relations, wp_e_submissions, wp_comments, y finalmente
   el propio registro en wp_users.
4. Se eliminan wp_user_members y wp_areas de la empresa, y finalmente el
   usuario group_admin (mismo procedimiento del paso 3).

Todo el proceso corre dentro de `START TRANSACTION` / `COMMIT`. Si
cualquier consulta falla, se ejecuta `ROLLBACK` y no se pierde ningún dato.

Nota importante sobre pedidos de WooCommerce (`wp_wc_orders` y tablas
relacionadas de líneas de pedido/facturación): este plugin NO elimina los
pedidos en sí, solo las tablas de "lookup"/analítica ligadas al customer_id
(`wp_wc_customer_lookup`, `wp_wc_order_product_lookup`, `wp_wc_order_stats`)
y los tokens de pago guardados. Se decidió así porque los pedidos suelen
tener implicaciones contables/legales de retención de información. Si
necesitas borrar también los pedidos completos, se puede extender
fácilmente `GE_Deletion_Service::delete_user_completely()` o usar el hook
`ge_delete_user_related_data`.

== Extensibilidad ==

* Hook `do_action( 'ge_delete_user_related_data', $user_id, $wpdb )`:
  se ejecuta dentro de la transacción, por cada usuario eliminado. Úsalo
  para limpiar tablas adicionales de plugins de terceros.
* Hook `do_action( 'ge_before_company_commit', $company_id, $area_ids, $member_user_ids )`:
  se ejecuta justo antes de eliminar a la propia empresa y de hacer COMMIT.

== Notas sobre la barra de progreso ==

La eliminación se ejecuta en el servidor dentro de una única transacción
atómica. No es seguro (ni realmente posible sin romper la atomicidad)
reportar avance real paso a paso mediante múltiples peticiones AJAX. Por
eso la barra de progreso avanza de forma progresiva mientras se espera la
respuesta del servidor y se completa al recibir el resultado final
(éxito o error). Mientras el proceso está en curso, un overlay bloquea
toda interacción con la página (evita múltiples clics).
