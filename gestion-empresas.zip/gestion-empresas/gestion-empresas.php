<?php
/**
 * Plugin Name:       Gestión de Empresas
 * Plugin URI:        https://elrincon-campus.local
 * Description:       Administra las empresas (usuarios con rol group_admin) del sistema: listado, búsqueda en tiempo real, conteo de áreas y eliminación en cascada segura mediante transacciones.
 * Version:           1.0.0
 * Author:            Cristian
 * Text Domain:       gestion-empresas
 * Domain Path:       /languages
 * Requires at least: 5.8
 * Requires PHP:      7.4
 */

// Evitar acceso directo.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ---------------------------------------------------------------------
// Constantes del plugin
// ---------------------------------------------------------------------
define( 'GE_PLUGIN_VERSION', '1.0.0' );
define( 'GE_PLUGIN_FILE', __FILE__ );
define( 'GE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'GE_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// Rol que identifica a una "empresa" dentro del sistema.
define( 'GE_COMPANY_ROLE', 'group_admin' );

// ---------------------------------------------------------------------
// Autoload sencillo de las clases del plugin
// ---------------------------------------------------------------------
require_once GE_PLUGIN_DIR . 'includes/class-ge-list-table.php';
require_once GE_PLUGIN_DIR . 'includes/services/class-ge-company-service.php';
require_once GE_PLUGIN_DIR . 'includes/services/class-ge-deletion-service.php';
require_once GE_PLUGIN_DIR . 'includes/class-ge-ajax-controller.php';
require_once GE_PLUGIN_DIR . 'includes/class-ge-admin-page.php';
require_once GE_PLUGIN_DIR . 'includes/class-ge-plugin.php';

/**
 * Arranca el plugin.
 */
function ge_run_plugin() {
	$plugin = new GE_Plugin();
	$plugin->init();
}
ge_run_plugin();
