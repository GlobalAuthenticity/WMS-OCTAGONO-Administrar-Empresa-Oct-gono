/* global jQuery, Swal, GE_Admin */
( function ( $ ) {
	'use strict';

	var $container   = $( '#ge-table-container' );
	var $searchInput = $( '#ge-search-input' );
	var $spinner     = $( '#ge-search-spinner' );
	var searchTimer  = null;
	var currentOrder = { orderby: 'id', order: 'desc' };

	/**
	 * Cierra cualquier menú de acciones abierto.
	 */
	function closeAllMenus() {
		$( '.ge-actions-menu' ).attr( 'hidden', true );
		$( '.ge-actions-toggle' ).attr( 'aria-expanded', 'false' );
	}

	/**
	 * Solicita al servidor el HTML actualizado de la tabla.
	 *
	 * @param {Object} params Parámetros adicionales (s, paged, orderby, order).
	 */
	function refreshTable( params ) {
		$spinner.addClass( 'is-active' );

		var data = $.extend(
			{
				action: 'ge_search_companies',
				nonce: GE_Admin.nonce,
				s: $searchInput.val(),
			},
			currentOrder,
			params || {}
		);

		$.post( GE_Admin.ajaxUrl, data )
			.done( function ( response ) {
				if ( response && response.success ) {
					$container.html( response.data.table_html );
				}
			} )
			.fail( function () {
				Swal.fire( {
					icon: 'error',
					title: GE_Admin.i18n.errorTitle,
					text: GE_Admin.i18n.genericError,
				} );
			} )
			.always( function () {
				$spinner.removeClass( 'is-active' );
			} );
	}

	// ---------------------------------------------------------------
	// Búsqueda en tiempo real (debounced).
	// ---------------------------------------------------------------
	$( document ).on( 'input', '#ge-search-input', function () {
		clearTimeout( searchTimer );
		searchTimer = setTimeout( function () {
			refreshTable( { paged: 1 } );
		}, 400 );
	} );

	$( document ).on( 'submit', '#ge-search-form', function ( e ) {
		e.preventDefault();
		refreshTable( { paged: 1 } );
	} );

	// ---------------------------------------------------------------
	// Paginación y orden (delegado, la tabla se reemplaza dinámicamente).
	// ---------------------------------------------------------------
	$( document ).on( 'click', '#ge-table-container .tablenav-pages a, #ge-table-container th.sortable a, #ge-table-container th.sorted a', function ( e ) {
		e.preventDefault();

		var url = $( this ).attr( 'href' );
		if ( ! url ) {
			return;
		}

		var params = {};
		var query  = url.split( '?' )[ 1 ] || '';

		query.split( '&' ).forEach( function ( pair ) {
			if ( ! pair ) {
				return;
			}
			var kv = pair.split( '=' );
			params[ decodeURIComponent( kv[ 0 ] ) ] = decodeURIComponent( kv[ 1 ] || '' );
		} );

		if ( params.orderby ) {
			currentOrder.orderby = params.orderby;
		}
		if ( params.order ) {
			currentOrder.order = params.order;
		}

		refreshTable( { paged: params.paged || 1 } );
	} );

	// ---------------------------------------------------------------
	// Menú de acciones por fila.
	// ---------------------------------------------------------------
	$( document ).on( 'click', '.ge-actions-toggle', function ( e ) {
		e.preventDefault();
		e.stopPropagation();

		var $menu   = $( this ).siblings( '.ge-actions-menu' );
		var wasOpen = ! $menu.attr( 'hidden' );

		closeAllMenus();

		if ( ! wasOpen ) {
			$menu.removeAttr( 'hidden' );
			$( this ).attr( 'aria-expanded', 'true' );
		}
	} );

	$( document ).on( 'click', function () {
		closeAllMenus();
	} );

	// ---------------------------------------------------------------
	// Eliminación de empresa: confirmación + progreso + resultado.
	// ---------------------------------------------------------------
	$( document ).on( 'click', '.ge-action-delete', function ( e ) {
		e.preventDefault();
		closeAllMenus();

		var companyId = $( this ).data( 'id' );
		var nombre    = $( this ).data( 'nombre' );

		Swal.fire( {
			icon: 'warning',
			title: GE_Admin.i18n.confirmTitle,
			html:
				'<p>' + GE_Admin.i18n.confirmTextPrefix + ' <strong>' + escapeHtml( nombre ) + '</strong> ' +
				GE_Admin.i18n.confirmTextSuffix + '</p>',
			showCancelButton: true,
			confirmButtonText: GE_Admin.i18n.confirmButton,
			cancelButtonText: GE_Admin.i18n.cancelButton,
			confirmButtonColor: '#b32d2e',
			focusCancel: true,
		} ).then( function ( result ) {
			if ( result.isConfirmed ) {
				performDelete( companyId );
			}
		} );
	} );

	/**
	 * Ejecuta el borrado vía AJAX mostrando una barra de progreso.
	 *
	 * Nota: la eliminación ocurre en el servidor dentro de UNA sola
	 * transacción atómica (START TRANSACTION / COMMIT / ROLLBACK), por lo
	 * que no es posible ni seguro reportar el avance real paso a paso sin
	 * romper la atomicidad. La barra avanza de forma progresiva mientras
	 * se espera la respuesta y se completa al 100% cuando el servidor
	 * confirma el resultado final.
	 *
	 * @param {number} companyId
	 */
	function performDelete( companyId ) {
		var $overlay = $( '#ge-progress-overlay' );
		var $fill    = $overlay.find( '.ge-progress-bar-fill' );
		var $title   = $overlay.find( '.ge-progress-title' );
		var $text    = $overlay.find( '.ge-progress-text' );

		$title.text( GE_Admin.i18n.progressTitle );
		$text.text( GE_Admin.i18n.progressText );
		$fill.css( 'width', '0%' );
		$overlay.removeAttr( 'hidden' );

		var progress = 0;
		var ticker   = setInterval( function () {
			progress = Math.min( progress + Math.random() * 12, 90 );
			$fill.css( 'width', progress + '%' );
		}, 300 );

		$.post( GE_Admin.ajaxUrl, {
			action: 'ge_delete_company',
			nonce: GE_Admin.nonce,
			company_id: companyId,
		} )
			.done( function ( response ) {
				clearInterval( ticker );
				$fill.css( 'width', '100%' );

				setTimeout( function () {
					$overlay.attr( 'hidden', true );

					if ( response && response.success ) {
						Swal.fire( {
							icon: 'success',
							title: GE_Admin.i18n.successTitle,
							text: response.data.message,
						} );
						refreshTable( {} );
					} else {
						var msg = ( response && response.data && response.data.message ) || GE_Admin.i18n.genericError;
						Swal.fire( {
							icon: 'error',
							title: GE_Admin.i18n.errorTitle,
							text: msg,
						} );
					}
				}, 300 );
			} )
			.fail( function ( jqXHR ) {
				clearInterval( ticker );
				$overlay.attr( 'hidden', true );

				var msg = GE_Admin.i18n.genericError;
				if ( jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.data && jqXHR.responseJSON.data.message ) {
					msg = jqXHR.responseJSON.data.message;
				}

				Swal.fire( {
					icon: 'error',
					title: GE_Admin.i18n.errorTitle,
					text: msg,
				} );
			} );
	}

	/**
	 * Escape básico para insertar texto dinámico en HTML de SweetAlert.
	 *
	 * @param {string} str
	 * @return {string}
	 */
	function escapeHtml( str ) {
		return $( '<div>' ).text( str || '' ).html();
	}
} )( jQuery );
